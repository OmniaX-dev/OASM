:orphan:

Welcome to Termcolor C++ library
================================

.. image:: _static/example.png
   :alt: termcolor in action
   :align: center

.. include:: ../README.rst
    :start-after: -*- inclusion-marker-for-sphinx-docs -*-
